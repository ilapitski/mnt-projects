module CompatResource
  VERSION = '12.9.1'
end
